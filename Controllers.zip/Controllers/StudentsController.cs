﻿using System.Web;
using SharpDevelopWebApi.Helpers.JWT;
using SharpDevelopWebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace SharpDevelopWebApi.Controllers
{
    public class StudentsController : ApiController
    {
        SDWebApiDbContext _db = new SDWebApiDbContext();
        
        [HttpGet]
        public IHttpActionResult GetAll(string keyword = "")
        {
            keyword = keyword.Trim();
            var students = new List<Students>();
            if(!string.IsNullOrEmpty(keyword))
            {
                students = _db.Students
                    .Where(x => x.LastName.Contains(keyword) || x.FirstName.Contains(keyword))
                    .ToList();
            }
            else
            	students = _db.Students.ToList();

            return Ok(students);
        }

        [HttpGet]
        public IHttpActionResult Get(int Id)
        {       
            var students = _db.Students.Find(Id);
            if (students != null)
                return Ok(students);
            else
                return BadRequest("Student not found");
        }

        //[ApiAuthorize]
        [HttpPost]
        public IHttpActionResult Create(Students newStudent)
        {
            _db.Students.Add(newStudent);
            _db.SaveChanges();
            return Ok(newStudent);
        }

        [HttpPut]
        public IHttpActionResult Update(Students updatedStudent)
        {
            var student = _db.Students.Find(updatedStudent.Id);
            if (student != null)
            {
                student.LastName = updatedStudent.LastName;
                student.FirstName = updatedStudent.FirstName;
                student.Gender = updatedStudent.Gender;
                student.CivilStatus = updatedStudent.CivilStatus;

                _db.Entry(student).State = System.Data.Entity.EntityState.Modified;
                _db.SaveChanges();

                return Ok(student);
            }
            else
                return BadRequest("Student not found");
        }

        [HttpDelete]
        public IHttpActionResult Delete(int Id)
        {
            var student = _db.Students.Find(Id);
            if (student != null)
            {
                _db.Students.Remove(student);
                _db.SaveChanges();
                return Ok("Student successfully deleted");
            }
            else
                return BadRequest("Student not found");
        }
        
//        [HttpPost]
//        [FileUpload.SwaggerForm()]
//        [Route("api/customer/{Id}/uploadphoto")]
//        public IHttpActionResult UploadPhoto(int Id)
//        {            
//            var student = _db.Students.Find(Id);
//            if (student != null)
//            {
//	        	var postedFile = HttpContext.Current.Request.Files[0];
//            	var filePath = postedFile.SaveAsJpegFile();
//            	if(!string.IsNullOrEmpty(filePath))
//            	{
//	            	student.PhotoUrl = filePath;
//	
//	                _db.Entry(student).State = System.Data.Entity.EntityState.Modified;
//	                _db.SaveChanges();
//	
//	                return Ok(student);            		
//            	}
//            }
//                       
//            return BadRequest("Error on photo uploading...");
//        }
    }
}
