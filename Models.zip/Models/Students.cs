﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace SharpDevelopWebApi.Models
{
	public class Students : Person
    {
        public string SchoolLastAttended{ get; set; }
        public int CourseId{ get; set; }
       
        [NotMapped]
        public string Photo { get; set; }        
        [JsonIgnore]
        public byte[] PhotoData { get; set; }
    }
}