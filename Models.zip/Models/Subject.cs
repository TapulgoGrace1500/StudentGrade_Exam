﻿public class Subject
{
	public int Id { get; set; }
	public string Code { get; set; }
	public string DescriptiveTitle { get; set; }
}