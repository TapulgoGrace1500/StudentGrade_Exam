﻿using System.ComponentModel.DataAnnotations.Schema;
using Newtonsoft.Json;
using SharpDevelopWebApi.Models;
public class Faculty: Person
{
	public string PhotoUrl {
		get;
		set;
	}

	public string SSSNumber { get; set; }
	public string Supervisor { get; set; }
	
	 [NotMapped]
      public string Photo { get; set; }        
     [JsonIgnore]
      public byte[] PhotoData { get; set; }
}