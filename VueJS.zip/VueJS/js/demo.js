function showMessage(){
    let message = 'Hello, How are you? Please continue...';
    alert(message);   
}

